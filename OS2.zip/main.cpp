#include <iostream>
#include <string>
#include <sstream>
#include <readline/readline.h>
#include <readline/history.h>
#include <unistd.h>
#include "utils.h"
#include "commands.h"

using namespace std;

int main(int argc, char **argv, char **envp)
{

    while (true)
    {

        char *in = readline(">> ");
        string inString(in);

        add_history(in);

        vector<vector<string>> commands;
        commands = Utils::parseLineCommands(inString);

        if(commands.size()==1) //one command
            for (vector<string> cmd : commands)
            {
                if(cmd[0] == "help")
                    Commands::help();
                if(cmd[0] == "version")
                    Commands::version();
                if (cmd[0] == "cd")
                    Commands::cd(cmd);
                if (cmd[0] == "pwd")
                    Commands::pwd();
                if (cmd[0] == "env")
                    Commands::env(cmd);
                if (cmd[0] == "basename")
                    Commands::baseName(cmd);
                if (cmd[0] == "exit")
                    Commands::exit(getpid());
                //cerr << "command not implemented\n";
        }
        else if (commands.size() > 1) //piping
        {
            int l[105][2];
            for(int i = 0; i < commands.size(); i++)
                pipe(l[i]);

            int pp[2];
            pipe(pp);
            int c = 0;
            while(c < commands.size())
            {
                int counter = 0;
                char **ccmd = (char **)malloc(100*sizeof(char*));
                for(int k = 0; k < commands[c].size(); k++)
                {
                    ccmd[counter] = (char*)commands[c][k].c_str();
                    counter+=1;
                }
                counter+=1;
                ccmd[counter] = NULL;
                if(fork()) c++;
                else
                {
                    if(c+1 != commands.size()) dup2(l[c+1][1], STDOUT_FILENO);
                    else
                        dup2(pp[1], STDOUT_FILENO);
                    if(c) dup2(l[c][0], STDIN_FILENO);
                    for(int i = 0; i < commands.size(); i++)
                    {
                        close(l[i][0]);
                        close(l[i][1]);
                    }
                    execvp(ccmd[0], ccmd);
                }
            }
            for(int i = 0; i < commands.size(); i++)
            {
                close(l[i][0]);
                close(l[i][1]);
            }
            wait(NULL);
            char buff[5000];
            int r = read(pp[0], &buff, 4999);
            buff[r] = '\0';
            printf("%s\n", buff);
        }

        delete in;
    }
    return 0;
}