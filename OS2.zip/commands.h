#ifndef COMMANDS_H
#define COMMANDS_H

#include <sys/wait.h>
#include <string>
#include <vector>
#include <unistd.h>
#include <iostream>

using namespace std;

extern char **environ;

class Commands
{
public:
    /*Print process env variables.Additional arguments are supplied in args*/
    static void env(vector<string> args)
    {
        int argc = args.size();

        if (argc == 1)
        {
            char **var = environ;
            while (*var != 0)
            {
                cout << *var << endl;
                var++;
            }
        }
        if (argc == 2)
        {
            if (args[1] == "-u")
                cerr << "env: -u optin requires an argument\n";
            else if (args[1][0] == '-')
                cerr << "env: unknown option " << args[1] << "\n";
        }
        if (argc == 3)
        {
            if (args[1] == "-u" && unsetenv(args[2].c_str()) != 0)
                cerr << "env: couldn't remove env variable\n";
            else if (args[1][0] == '-' && args[1][1] != 'u')
                cerr << "env: unknown option " << args[1] << "\n";
        }
    }

    /*Change current working directory to arg*/
   static void cd(vector<string> args)
    {
        int argc = args.size();
        if (argc > 2)
        {
            cerr << "shell: cd: too many arguments\n";
            return;
        }
        if (argc == 2)
        {
	        int res;
            if (args[1] != "~")
                res = chdir(args[1].c_str());
            else
                res = chdir(getenv("HOME"));
	        if (res == -1) cerr << "shell: cd: no such file or directory\n";
            else
	       {
			char *PWDENV = (char *)malloc(256);
			strcpy(PWDENV, "PWD=");
			strcat(PWDENV, getcwd((char *) NULL, 0));
			putenv(PWDENV);
		    }
        }
    }

    //print current wordking directory
    static void pwd()
    {
        char camino[256];
        getcwd(camino, 256);
        cout << camino << endl;
    }

    /*Print the basename*/
    static void baseName(vector<string> args)
    {
        if (args.size() == 1)
        {
            cerr << "shell: basename: no argument provided\n";
            return;
        }
        cout << basename(args[1].c_str()) << endl;
    }

    /*help function*/
    static void help()
    {
        cout << "Help menu\n"
            <<"Supported commands:\n"
            <<" - env\n"
            <<" - cd\n"
            <<" -basename\n"
            <<" - help\n"
            <<" - version\n"
            <<" - exit\n";
    }

    /* version function*/
    static void version()
    {
        cout<<"Author: Raluca Chis\n"
            <<"Static hostname: ralu-VirtualBox\n"
            <<"Icon name: computer-vm\n"
            <<"Chassis: vm\n"
            <<"Machine ID: 50a7e775815d4161a2ead972f92a05d0\n"
            <<"Boot ID: 3d85266c411240d684f5993851a7e808\n"
            <<"Virtualization: oracle\n"
            <<"Operating System: Ubuntu 20.04.1 LTS\n"
            <<"Kernel: Linux 5.4.0-58-generic\n"
            <<"Architecture: x86-64\n";
    }

    /*Exit shell by killing the main process*/
    static void exit(int pid)
    {
        kill(pid, SIGKILL);
    }


private:
    Commands();
};

#endif